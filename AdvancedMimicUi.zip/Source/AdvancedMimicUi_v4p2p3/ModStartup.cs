﻿using HarmonyLib;
using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace ModManagement
{
    public static class ModStartup
    {
        //[DllImport("kernel32.dll")]
        //private static extern bool AllocConsole();

        /*
        public static void OnLoad()
        {
        }
        */

        public static void OnStart()
        {
            //AllocConsole();
            //Console.SetOut(new StreamWriter(Console.OpenStandardOutput()) { AutoFlush = true });

            ModInformation.VersionConfirmation();

            Harmony harmony = new Harmony("AdvancedMimicUiPatch");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }

        /*
        public static void OnSave()
        {
        }
        */
    }
}
