﻿using BrilliantSkies.Blocks.Decorative;
using BrilliantSkies.Core.Collections.Arrays;
using BrilliantSkies.Core.Types;
using BrilliantSkies.Ftd.Avatar.Build;
using BrilliantSkies.Ftd.Constructs.Modules.All.Decorations;
using BrilliantSkies.Ui.Consoles;
using BrilliantSkies.Ui.Consoles.Interpretters.Subjective.Numbers;
using BrilliantSkies.Ui.Consoles.Styles;
using BrilliantSkies.Ui.Displayer;
using BrilliantSkies.Ui.Tips;
using HarmonyLib;
using HuwaTech;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace AdvancedMimicUi
{
    internal class AdvancedMimicUiPatch
    {
        [HarmonyPatch(typeof(Mimic), "Secondary", new Type[] { typeof(Transform) })]
        private class Mimic_Secondary_Patch
        {
            private static bool Prefix(Mimic __instance)
            {
                new HuwaMimicUi(__instance).ActivateGui(GuiActivateType.Standard);

                return false;
            }
        }

        [HarmonyPatch(typeof(Mimic), "AppendToolTip", new Type[] { typeof(ProTip) })]
        private class Mimic_AppendToolTip_Patch
        {
            private static bool Prefix(Mimic __instance, ProTip tip)
            {
                string name = HuwaHelpFunctions.GetItemName(__instance.Data.MeshGuid);

                //ProTipSegment_LinesOfText proTipSegment_LinesOfText = tip.Add(new ProTipSegment_LinesOfText(500), Position.Last);
                //proTipSegment_LinesOfText.AddExtraLine($"Selected mesh : \n<<{name}>>");



                //__instance.AppendToolTip(tip);

                bool bm = cBuild.GetSingleton().buildMode != 0;

                if (!__instance.Data.HideTooltip || bm)
                {
                    tip.Add(new ProTipSegment_TitleSubTitle(Mimic._locFile.Get("SpecialName", "Mimic"), Mimic._locFile.Get("SpecialDescription", "Mimics the appearance of any other block")));
                    tip.Add(new ProTipSegment_Text(300, $"Mimicked block : <<{name}>>"));
                    tip.InfoOnly = false;

                    if (bm) __instance.LocateMeshContour();
                }

                return false;
            }
        }



        [HarmonyPatch(typeof(AllConstructDecorations), "AddOrEditDecorations", new Type[] { typeof(Vector3i) })]
        private class AllConstructDecorations_AddOrEditDecorations_Patch
        {
            private static bool Prefix(AllConstructDecorations __instance, Vector3i position, ref MultiDecorationEditor? __result)
            {
                List<Decoration> decorationsAtPosition;
                ThreeDDictionary<List<Decoration>> decorationArray = Traverse.Create(__instance).Field("_decorationArray").GetValue<ThreeDDictionary<List<Decoration>>>();
                AllConstruct construct = Traverse.Create(__instance).Property("_construct").GetValue<AllConstruct>();

                if (decorationArray.TryRead(position.x, position.y, position.z, out decorationsAtPosition))
                {
                    __result = new HuwaMultiDecorationUi(new DecorationsSubject(__instance, position, decorationsAtPosition, construct.Main.ColorsRestricted));
                    __result.ActivateGui(GuiActivateType.Stack);

                }
                else if (__instance.CanAddHere(position))
                {
                    __result = new HuwaMultiDecorationUi(new DecorationsSubject(__instance, position, null, construct.Main.ColorsRestricted));
                    __result.ActivateGui(GuiActivateType.Stack);
                }
                else
                {
                    __result = null;
                }

                return false;
            }
        }

        [HarmonyPatch(typeof(MultiDecorationEditor), "DisplayAScreenForThis", new Type[] { typeof(Decoration) })]
        private class MultiDecorationEditor_DisplayAScreenForThis_Patch
        {
            private static bool Prefix(MultiDecorationEditor __instance, Decoration decoration)
            {
                ConsoleWindow window = Traverse.Create(__instance).Field("_window").GetValue<ConsoleWindow>();

                DecorationTab decorationTab = new HuwaDecorationEditorTab(window, decoration, __instance._focus.Decorations.Count - 1);
                decorationTab.Build();
                window.AllScreens.Add(decorationTab);
                window.Screen = decorationTab;
                __instance._focus.FocusThisWidget(decoration);

                return false;
            }
        }

        [HarmonyPatch(typeof(DecorationsSubject), "SpawnDecorationWidget")]
        private class DecorationsSubject_SpawnDecorationWidget_Patch
        {
            private static void Postfix(DecorationsSubject __instance)
            {
                __instance._camera.CanSelect = (() => __instance.Ui.Windows.All(I => !I.MouseOnScreenLastOnGui));
            }
        }



        [HarmonyPatch(typeof(ABar), "PrimaryLayout", new Type[] { typeof(SO_BuiltUi), typeof(StylePlus), typeof(string), typeof(string) })]
        private class ABar_PrimaryLayout_Patch
        {
            private static bool Prefix(ABar __instance, ref Rect __result, ref SO_BuiltUi styles, ref StylePlus styleForBar, ref string displayString, ref string tipCode, ref bool ____simpleLayout, ref bool ____anyHeldDown, ref float ____lastWidthUsed)
            {
                ABar_AddMember AM = ClassExpansion<ABar, ABar_AddMember>.Access(__instance);

                bool simpleLayout = ____simpleLayout;
                Rect result;
                if (simpleLayout)
                {
                    styleForBar.Layout(displayString, tipCode, Array.Empty<GUILayoutOption>());
                    result = GUILayoutUtility.GetLastRect();
                }
                else
                {
                    bool flag = ____anyHeldDown && ____lastWidthUsed != -1f;
                    if (flag)
                    {
                        styleForBar.Layout(displayString, tipCode, new GUILayoutOption[]
                        {
                        GUILayout.MinWidth(____lastWidthUsed),
                        GUILayout.MaxWidth(____lastWidthUsed)
                        });
                        Rect lastRect = GUILayoutUtility.GetLastRect();
                        bool flag2 = Event.current.type == EventType.Repaint;
                        if (flag2)
                        {
                            ____lastWidthUsed = lastRect.width;
                        }
                        result = lastRect;
                    }
                    else
                    {
                        bool flag3 = ____lastWidthUsed == -1f;
                        if (flag3)
                        {
                            styleForBar.Layout(displayString, tipCode, Array.Empty<GUILayoutOption>());
                        }
                        else
                        {
                            if (AM.FastWidthOptimization)
                            {
                                styleForBar.Layout(displayString, tipCode, new GUILayoutOption[]
                                {
                                    GUILayout.MinWidth(0f),
                                    GUILayout.MaxWidth(1280f)
                                });
                            }
                            else
                            {
                                styleForBar.Layout(displayString, tipCode, new GUILayoutOption[]
                                {
                                    GUILayout.MinWidth(____lastWidthUsed - 15f),
                                    GUILayout.MaxWidth(____lastWidthUsed + 15f)
                                });
                            }
                        }
                        Rect lastRect2 = GUILayoutUtility.GetLastRect();
                        bool flag4 = Event.current.type == EventType.Repaint;
                        if (flag4)
                        {
                            ____lastWidthUsed = lastRect2.width;
                        }
                        result = lastRect2;
                    }
                }
                __result = result;

                return false;
            }
        }
    }
}
