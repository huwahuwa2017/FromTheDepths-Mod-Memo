﻿using BrilliantSkies.Ftd.Constructs.Modules.All.Decorations;
using BrilliantSkies.Ui.Consoles;
using BrilliantSkies.Ui.Consoles.Getters;
using BrilliantSkies.Ui.Consoles.Interpretters.Simple;
using BrilliantSkies.Ui.Consoles.Interpretters.Subjective;
using BrilliantSkies.Ui.Consoles.Interpretters.Subjective.Buttons;
using BrilliantSkies.Ui.Consoles.Segments;
using BrilliantSkies.Ui.Layouts.DropDowns;
using BrilliantSkies.Ui.Tips;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace AdvancedMimicUi
{
    public class HuwaDecorationMassEditorControlTab : SuperScreen<DecorationsSubject>
    {
        private HuwaDecorationMassEditorUi _mainUi;

        public override Content Name
        {
            get
            {
                return new Content("Mass editor control", null, "HuwaDecorationMassEditorControlTab");
            }
        }

        public HuwaDecorationMassEditorControlTab(ConsoleWindow window, DecorationsSubject focus, HuwaDecorationMassEditorUi mainUi) : base(window, focus)
        {
            _mainUi = mainUi;
        }

        public override void Build()
        {
            ScreenSegmentStandardHorizontal screenSegment_0 = CreateStandardHorizontalSegment();
            screenSegment_0.SpaceAbove = 10f;

            screenSegment_0.AddInterpretter(SubjectiveDisplay<int>.Quick(default, M.m<int>("Rotation origin  :"))).Justify = TextAnchor.UpperRight;

            DropDownMenuAlt<Decoration> dropDownMenuAlt = new DropDownMenuAlt<Decoration>();
            List<DropDownMenuAltItem<Decoration>> dropDownItemList = new List<DropDownMenuAltItem<Decoration>> { new DropDownMenuAltItem<Decoration>() { Name = "Default", ObjectForAction = null } };
            dropDownItemList.AddRange(_focus.Decorations.Select((deco, index) => new DropDownMenuAltItem<Decoration>() { Name = "Decoration No." + index, ObjectForAction = deco }));
            dropDownMenuAlt.SetItems(dropDownItemList.ToArray());

            screenSegment_0.AddInterpretter(new DropDown<int, Decoration>(default, dropDownMenuAlt, (int _, Decoration I) => _mainUi.OriginDecoration == I, (int _, Decoration I) => _mainUi.OriginDecoration = I));



            ScreenSegmentStandard screenSegment_1 = CreateStandardSegment();
            screenSegment_1.SpaceAbove = 10f;
            screenSegment_1.SpaceBelow = 20f;

            screenSegment_1.AddInterpretter(SubjectiveButton<int>.Quick(default, "Cancel position", new ToolTip("Cancel position based on the selected decoration"), _ => _mainUi.CancelPosition()))
                .FadeOut = M.m<int>(_ => _mainUi.OriginDecoration == null);

            screenSegment_1.AddInterpretter(SubjectiveButton<int>.Quick(default, "Cancel rotation", new ToolTip("Cancel rotation based on the selected decoration"), _ => _mainUi.CancelRotation()))
                .FadeOut = M.m<int>(_ => _mainUi.OriginDecoration == null);
        }
    }
}
