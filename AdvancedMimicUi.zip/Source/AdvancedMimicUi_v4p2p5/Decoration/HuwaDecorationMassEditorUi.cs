﻿using BrilliantSkies.Core.Drawing;
using BrilliantSkies.Core.Types;
using BrilliantSkies.Ftd.Constructs.Modules.All.Decorations;
using BrilliantSkies.Ui.Consoles;
using EndlessShapes2.Polygon;
using HarmonyLib;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace AdvancedMimicUi
{
    public class HuwaDecorationMassEditorUi : ConsoleUi<DecorationsSubject>
    {
        private struct TempData
        {
            public Decoration _decoration;

            public Vector3 _positioning;

            public Vector3 _scaling;

            public Vector3 _orientation;

            public TempData(Decoration deco)
            {
                _decoration = deco;
                _positioning = deco.Positioning.Us;
                _scaling = deco.Scaling.Us;
                _orientation = deco.Orientation.Us;
            }
        }

        private ConsoleWindow _consoleWindow_0;
        private ConsoleWindow _consoleWindow_1;

        private AllConstruct _targetAllConstruct;
        private List<TempData> _tempDataList;

        private Vector3 _preOriginPosition;
        private Vector3 _prePositioning;
        private Vector3 _preOrientation;
        private float _preScaling;

        public Decoration OriginDecoration { get; set; }

        public MimicAndDecorationCommonData FakeMAD_Data { get; set; }

        public bool UndoReservation { get; set; } = true;

        public HuwaDecorationMassEditorUi(DecorationsSubject subject) : base(subject)
        {
            _targetAllConstruct = Traverse.Create(_focus.ConstructDecorations).Property("_construct").GetValue<AllConstruct>();
            _tempDataList = _focus.Decorations.Select(I => new TempData(I)).ToList();
            FakeMAD_Data = new MimicAndDecorationCommonData();
        }

        protected override ConsoleWindow BuildInterface(string suggestedName = "")
        {
            _consoleWindow_0 = NewWindow(0, "Mass editor", new ScaledRectangle(10f, 10f, 600f, 0f));
            _consoleWindow_0.DisplayTextPrompt = false;
            _consoleWindow_0.SetMultipleTabs(new HuwaDecorationMassEditorTab(_consoleWindow_0, _focus, this));

            _consoleWindow_1 = NewWindow(2, "Other", new ScaledRectangle(670f, 10f, 600f, 230f));
            _consoleWindow_1.DisplayTextPrompt = false;
            _consoleWindow_1.MinimumWindowHeight = new PixelSizing(35f, Dimension.Height);
            _consoleWindow_1.SetMultipleTabs(new HuwaDecorationMassEditorControlTab(_consoleWindow_1, _focus, this), new HuwaCalculatorTab(_consoleWindow_1), new HuwaDecorationSettingsTab(_consoleWindow_1, _focus));

            return _consoleWindow_0;
        }

        public override void LateUpdateWhenActive()
        {
            base.LateUpdateWhenActive();

            Vector3 originPosition = _tempDataList.FirstOrDefault(I => I._decoration == OriginDecoration)._positioning;
            Vector3 positioning = FakeMAD_Data.Positioning;
            Vector3 orientation = FakeMAD_Data.Orientation;
            float scaling = FakeMAD_Data.ScalingX;

            bool flag_0 = _preOriginPosition != originPosition;
            bool flag_1 = _prePositioning != positioning;
            bool flag_2 = _preOrientation != orientation;
            bool flag_3 = _preScaling != scaling;

            if (flag_0 || flag_1 || flag_2 || flag_3)
            {
                _preOriginPosition = originPosition;
                _prePositioning = positioning;
                _preOrientation = orientation;
                _preScaling = scaling;

                foreach (TempData td in _tempDataList)
                {
                    td._decoration.Positioning.Us = Quaternion.Euler(orientation) * (td._positioning - originPosition) * scaling + originPosition + positioning;
                    td._decoration.Orientation.Us = (Quaternion.Euler(orientation) * Quaternion.Euler(td._orientation)).eulerAngles;
                    td._decoration.Scaling.Us = td._scaling * scaling;
                }
            }

            Vector3i tetherPoint = Traverse.Create(_focus).Field("_point").GetValue<Vector3i>();
            Vector3 localPosition = tetherPoint + originPosition + positioning;
            Vector3 up = Quaternion.Euler(0f, Time.time * 360f % 360f, 0f) * Vector3.forward;
            VectorLines.i.Current.Circle(_targetAllConstruct.SafeLocalToGlobal(localPosition), 0.15f, Color.magenta, up, 2f, 4);
        }

        public override void OnDeactivateGui()
        {
            base.OnDeactivateGui();

            if (UndoReservation)
            {
                foreach (TempData td in _tempDataList)
                {
                    td._decoration.Positioning.Us = td._positioning;
                    td._decoration.Orientation.Us = td._orientation;
                    td._decoration.Scaling.Us = td._scaling;
                }
            }
            else
            {
                foreach (TempData td in _tempDataList)
                {
                    td._decoration.Positioning.Us = HuwaHelpFunctions.RoundingR4Vector3(td._decoration.Positioning.Us);
                    td._decoration.Orientation.Us = HuwaHelpFunctions.RoundingR4Vector3(td._decoration.Orientation.Us);
                    td._decoration.Scaling.Us = HuwaHelpFunctions.RoundingR4Vector3(td._decoration.Scaling.Us);
                }
            }
        }

        public void CancelPosition()
        {
            if (OriginDecoration != null)
            {
                Vector3 temp_0 = _tempDataList.FirstOrDefault(I => I._decoration == OriginDecoration)._positioning;
                FakeMAD_Data.Positioning = -temp_0;
            }
        }

        public void CancelRotation()
        {
            if (OriginDecoration != null)
            {
                Vector3 temp_0 = _tempDataList.FirstOrDefault(I => I._decoration == OriginDecoration)._orientation;
                FakeMAD_Data.Orientation = Quaternion.Inverse(Quaternion.Euler(temp_0)).eulerAngles;
            }
        }

        /*
        public DecorationsSubject GetDecorationsSubject()
        {
            return _focus;
        }

        public bool GetDecoration(out Decoration deco)
        {
            if (_consoleWindow_0 != null)
            {
                ConsoleUiScreen screen = _consoleWindow_0.Screen;

                if (screen is HuwaDecorationEditorTab)
                {
                    deco = Traverse.Create(screen as HuwaDecorationEditorTab).Field("_focus").GetValue<Decoration>();
                    return true;
                }
            }

            deco = null;
            return false;
        }
        */
    }
}
