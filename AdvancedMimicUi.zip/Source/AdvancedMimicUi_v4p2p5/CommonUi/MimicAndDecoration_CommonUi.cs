﻿using BrilliantSkies.Core.Help;
using BrilliantSkies.Ftd.Constructs.Modules.All.Decorations;
using BrilliantSkies.Modding;
using BrilliantSkies.Modding.Types;
using BrilliantSkies.Ui.Consoles;
using BrilliantSkies.Ui.Consoles.Getters;
using BrilliantSkies.Ui.Consoles.Interpretters;
using BrilliantSkies.Ui.Consoles.Interpretters.Simple;
using BrilliantSkies.Ui.Consoles.Interpretters.Subjective.Choices;
using BrilliantSkies.Ui.Consoles.Interpretters.Subjective.Numbers;
using BrilliantSkies.Ui.Consoles.Segments;
using BrilliantSkies.Ui.Layouts.DropDowns;
using BrilliantSkies.Ui.Tips;
using EndlessShapes2.Polygon;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace AdvancedMimicUi
{
    public static class MimicAndDecoration_CommonUi
    {
        private static string _resetText = "Reset";

        private static string _minusText = "-";

        private static string _plusText = "+";

        private static string _addMinusText = "Add -";

        private static string _addPlusText = "Add +";

        private static Func<string>[] Texts = new Func<string>[]
        {
            () => _minusText + HuwaSettingsTab.AddPosition.ToString(),
            () => _plusText + HuwaSettingsTab.AddPosition.ToString(),
            () => _minusText + HuwaSettingsTab.AddScale.ToString(),
            () => _plusText + HuwaSettingsTab.AddScale.ToString(),
            () => _minusText + HuwaSettingsTab.AddAngle.ToString(),
            () => _plusText + HuwaSettingsTab.AddAngle.ToString()
        };

        private static Func<string>[] ToolTips = new Func<string>[]
        {
            () => _addMinusText + HuwaSettingsTab.AddPosition.ToString(),
            () => _addPlusText + HuwaSettingsTab.AddPosition.ToString(),
            () => _addMinusText + HuwaSettingsTab.AddScale.ToString(),
            () => _addPlusText + HuwaSettingsTab.AddScale.ToString(),
            () => _addMinusText + HuwaSettingsTab.AddAngle.ToString(),
            () => _addPlusText + HuwaSettingsTab.AddAngle.ToString()
        };

        public static void PositioningBarsUiGeneration(ScreenSegmentTable screenSegmentTable, HuwaUi<MimicAndDecorationCommonData> hUi_0)
        {
            SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[] subjectiveFloats = new SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[3];

            subjectiveFloats[0] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -20f, 20f, 0.05f, 0f, M.m<MimicAndDecorationCommonData>(I => I.Positioning.x), "Left right positioning {0}", (I, f) => I.PositioningX = f, new ToolTip("Adjust the left right positioning of the mesh"));
            subjectiveFloats[1] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -20f, 20f, 0.05f, 0f, M.m<MimicAndDecorationCommonData>(I => I.Positioning.y), "Up down positioning {0}", (I, f) => I.PositioningY = f, new ToolTip("Adjust the up down positioning of the mesh"));
            subjectiveFloats[2] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -20f, 20f, 0.05f, 0f, M.m<MimicAndDecorationCommonData>(I => I.Positioning.z), "Forward backward positioning {0}", (I, f) => I.PositioningZ = f, new ToolTip("Adjust the forward backward positioning of the mesh"));

            foreach (SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData> s in subjectiveFloats)
            {
                s.ClampInput = false;
                s.TextBox.ForceRounding = false;
                HuwaUi.ABar_AddMember_Access(s).FastWidthOptimization = true;
            }

            screenSegmentTable.AddInterpretter(subjectiveFloats[0]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.PositioningX *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[0], ToolTips[0], I => I.PositioningX -= HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[1], ToolTips[1], I => I.PositioningX += HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.PositioningX = 0f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[1]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.PositioningY *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[0], ToolTips[0], I => I.PositioningY -= HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[1], ToolTips[1], I => I.PositioningY += HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.PositioningY = 0f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[2]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.PositioningZ *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[0], ToolTips[0], I => I.PositioningZ -= HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[1], ToolTips[1], I => I.PositioningZ += HuwaSettingsTab.AddPosition));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.PositioningZ = 0f));
        }

        public static void ScalingBarsUiGeneration(ScreenSegmentTable screenSegmentTable, HuwaUi<MimicAndDecorationCommonData> hUi_0)
        {
            SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[] subjectiveFloats = new SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[3];

            subjectiveFloats[0] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, 0.05f, 10f, 0.05f, 1f, M.m<MimicAndDecorationCommonData>(I => I.Scaling.x), "Left right scaling {0}", (I, f) => I.ScalingX = f, new ToolTip("Adjust the left right scaling of the mesh"));
            subjectiveFloats[1] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, 0.05f, 10f, 0.05f, 1f, M.m<MimicAndDecorationCommonData>(I => I.Scaling.y), "Up down scaling {0}", (I, f) => I.ScalingY = f, new ToolTip("Adjust the up down scaling of the mesh"));
            subjectiveFloats[2] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, 0.05f, 10f, 0.05f, 1f, M.m<MimicAndDecorationCommonData>(I => I.Scaling.z), "Forward backward scaling {0}", (I, f) => I.ScalingZ = f, new ToolTip("Adjust the forward backward scaling of the mesh"));

            foreach (SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData> s in subjectiveFloats)
            {
                s.ClampInput = false;
                s.TextBox.ForceRounding = false;
                HuwaUi.ABar_AddMember_Access(s).FastWidthOptimization = true;
            }

            screenSegmentTable.AddInterpretter(subjectiveFloats[0]);
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[2], ToolTips[2], I => I.ScalingX -= HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[3], ToolTips[3], I => I.ScalingX += HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.ScalingX = 1f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[1]);
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[2], ToolTips[2], I => I.ScalingY -= HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[3], ToolTips[3], I => I.ScalingY += HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.ScalingY = 1f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[2]);
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[2], ToolTips[2], I => I.ScalingZ -= HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[3], ToolTips[3], I => I.ScalingZ += HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.ScalingZ = 1f));
        }

        public static void OrientationBarsUiGeneration(ScreenSegmentTable screenSegmentTable, HuwaUi<MimicAndDecorationCommonData> hUi_0)
        {
            SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[] subjectiveFloats = new SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>[3];

            subjectiveFloats[0] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -180f, 180f, 0.1f, 0f, M.m<MimicAndDecorationCommonData>(I => Rounding.R1(Angles.FixRot180To180(I.Orientation.y))), "Yaw {0:0.##}", (I, f) => I.OrientationY = f, new ToolTip("Adjust the yaw of the mesh"));
            subjectiveFloats[1] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -90f, 90f, 0.1f, 0f, M.m<MimicAndDecorationCommonData>(I => -Rounding.R1(Angles.FixRot180To180(I.Orientation.x))), "Pitch {0:0.##}", (I, f) => I.OrientationX = -f, new ToolTip("Adjust the pitch of the mesh"));
            subjectiveFloats[2] = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, -180f, 180f, 0.1f, 0f, M.m<MimicAndDecorationCommonData>(I => Rounding.R1(Angles.FixRot180To180(I.Orientation.z))), "Roll {0:0.##}", (I, f) => I.OrientationZ = f, new ToolTip("Adjust the roll of the mesh"));

            foreach (SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData> s in subjectiveFloats)
            {
                s.ClampInput = false;
                s.TextBox.ForceRounding = false;
                HuwaUi.ABar_AddMember_Access(s).FastWidthOptimization = true;
            }

            screenSegmentTable.AddInterpretter(subjectiveFloats[0]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.OrientationY *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[4], ToolTips[4], I => I.OrientationY -= HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[5], ToolTips[5], I => I.OrientationY += HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.OrientationY = 0f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[1]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.OrientationX *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[4], ToolTips[4], I => I.OrientationX += HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[5], ToolTips[5], I => I.OrientationX -= HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.OrientationX = 0f));

            screenSegmentTable.AddInterpretter(subjectiveFloats[2]);
            screenSegmentTable.AddInterpretter(hUi_0.FlipButton(I => I.OrientationZ *= -1f));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[4], ToolTips[4], I => I.OrientationZ -= HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[5], ToolTips[5], I => I.OrientationZ += HuwaSettingsTab.AddAngle));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.OrientationZ = 0f));
        }

        public static void MassScalingBarUiGeneration(ScreenSegmentTable screenSegmentTable, HuwaUi<MimicAndDecorationCommonData> hUi_0)
        {
            SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData> subjectiveFloat = SubjectiveFloatClampedWithBarFromMiddle<MimicAndDecorationCommonData>.Quick(
                hUi_0.Focus, 0.05f, 10f, 0.05f, 1f, M.m<MimicAndDecorationCommonData>(I => I.Scaling.x), "Scaling {0}", (I, f) => I.ScalingX = f, new ToolTip("Adjust the scaling of the mesh"));

            subjectiveFloat.ClampInput = false;
            subjectiveFloat.TextBox.ForceRounding = false;
            HuwaUi.ABar_AddMember_Access(subjectiveFloat).FastWidthOptimization = true;

            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());

            screenSegmentTable.AddInterpretter(subjectiveFloat);
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[2], ToolTips[2], I => I.ScalingX -= HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(Texts[3], ToolTips[3], I => I.ScalingX += HuwaSettingsTab.AddScale));
            screenSegmentTable.AddInterpretter(hUi_0.AddButton(_resetText, _resetText, I => I.ScalingX = 1f));

            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
            screenSegmentTable.AddInterpretter(new Empty());
        }

        public static SubjectiveToggle<Decoration> GetHideOriginalMeshToggle(Decoration focus)
        {
            ToolTip toolTip = new ToolTip(DecorationTab._locFile.Get("Toggle_HideOriginalMesh_Tip", "If true, the mesh of the block we are tethering to will be hidden. Only works for static blocks."));

            SubjectiveToggle<Decoration> subjectiveToggle = SubjectiveToggle<Decoration>.Quick(focus, DecorationTab._locFile.Get("Toggle_HideOriginalMesh", "Hide original mesh"), toolTip,
                (Decoration I, bool b) =>
                {
                    I.SetHideOriginalMesh(b);
                },
                (Decoration I) =>
                {
                    return I.GetHideOriginalMesh();
                });

            return subjectiveToggle;
        }

        public static SubjectiveToggle<DecorationsSubject> GetHideOriginalMeshToggle(DecorationsSubject focus)
        {
            ToolTip toolTip = new ToolTip(DecorationTab._locFile.Get("Toggle_HideOriginalMesh_Tip", "If true, the mesh of the block we are tethering to will be hidden. Only works for static blocks."));

            SubjectiveToggle<DecorationsSubject> subjectiveToggle = SubjectiveToggle<DecorationsSubject>.Quick(focus, DecorationTab._locFile.Get("Toggle_HideOriginalMesh", "Hide original mesh"), toolTip,
                (DecorationsSubject I, bool b) =>
                {
                    if (I.Decorations.Count == 0) I.AddNewDecoration();
                    I.Decorations[0].SetHideOriginalMesh(b);
                },
                (DecorationsSubject I) =>
                {
                    if (I.Decorations.Count == 0) return false;
                    return I.Decorations[0].GetHideOriginalMesh();
                });

            return subjectiveToggle;
        }

        public static ScreenSegmentStandardHorizontal AxisFlip<T>(ConsoleUiScreen screen, HuwaUi<T> hUi_0, Action<T> actionX, Action<T> actionY, Action<T> actionZ)
        {
            ScreenSegmentStandardHorizontal screenSegment = screen.CreateStandardHorizontalSegment();

            screenSegment.AddInterpretter(hUi_0.AddButton("X axis flip", "Reverses the position and angle based on the X axis.", actionX));
            screenSegment.AddInterpretter(hUi_0.AddButton("Y axis flip", "Reverses the position and angle based on the Y axis.", actionY));
            screenSegment.AddInterpretter(hUi_0.AddButton("Z axis flip", "Reverses the position and angle based on the Z axis.", actionZ));

            return screenSegment;
        }

        public static ScreenSegmentStandardHorizontal MaterialReplacementDropDown(ConsoleUiScreen screen, MimicAndDecorationCommonData madcd)
        {
            ScreenSegmentStandardHorizontal screenSegment = screen.CreateStandardHorizontalSegment();
            DropDownMenuAlt<Guid> dropDownMenuAlt = new DropDownMenuAlt<Guid>(TextAnchor.MiddleCenter);
            List<DropDownMenuAltItem<Guid>> list = new List<DropDownMenuAltItem<Guid>>();

            list.Add(new DropDownMenuAltItem<Guid>
            {
                ObjectForAction = Guid.Empty,
                Name = "No material override",
                ToolTip = "Don't override the material"
            });

            foreach (MaterialDefinition materialDefinition in Configured.i.Materials.Components)
            {
                list.Add(new DropDownMenuAltItem<Guid>
                {
                    ObjectForAction = materialDefinition.ComponentId.Guid,
                    ToolTip = "Don't expect all materials to work. Alloy, metal, rubber, stone and heavy armour are tri-planar mapped and can fit to any mesh. Other materials have different texture atlas layouts and will not readily swap between meshes. The emissivity-only texture will work on anything.",
                    Name = materialDefinition.ComponentId.Name.ToString()
                });
            }

            dropDownMenuAlt.SetItems(list.ToArray());
            screenSegment.AddInterpretter(new DropDown<MimicAndDecorationCommonData, Guid>(madcd, dropDownMenuAlt, (I, e) => I.MaterialReplacement == e, (I, e) => I.MaterialReplacement = e));

            return screenSegment;
        }
    }
}
